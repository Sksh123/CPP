// power function
#include <bits/stdc++.h>
using namespace std;
  
int main()
{
    double x;
    int y;
  
  
    std::cout << "Enter a number (x): ";
    std::cin >> x;

    std::cout << "Enter the exponent (y): ";
    std::cin >> y;
    
    // if (std::cin.peek() == '\n') {
    //     // User didn't enter a value, use the default (2)
    //     y = 2;
    // } else {
    //     std::cin >> y;
    // }
    // Storing the answer in result.
    double result = pow(x, y);
  
    // printing the result upto 2
    // decimal place
    cout << fixed << setprecision(2) << result << endl;
  
    return 0;
}