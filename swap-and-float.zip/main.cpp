#include<iostream>
#include<conio.h>

void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}

void swap(float& x, float& y) {
    float temp = x;
    x = y;
    y = temp;
}

void clearScreen() {
    std::cout << "\033[2J\033[1;1H"; // ANSI escape code to clear the screen
}

int main() {
    clearScreen(); // Call the clearScreen function to clear the screen

    int a, b;
    float x, y;

    std::cout << "Enter the first integer (a): ";
    std::cin >> a;

    std::cout << "Enter the second integer (b): ";
    std::cin >> b;

    swap(a, b);

    std::cout << "\nInteger values after swapping are: " << a << " " << b << std::endl;

    std::cout << "Enter the first float (x): ";
    std::cin >> x;

    std::cout << "Enter the second float (y): ";
    std::cin >> y;

    swap(x, y);

    std::cout << "\nFloat values after swapping are: " << x << " " << y << std::endl;

    getch();
    return 0;
}
