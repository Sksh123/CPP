#include <iostream>
using namespace std;

class Time {
private:
    int HR, MIN, SEC;

public:
    void setTime(int x, int y, int z) {
        HR = x;
        MIN = y;
        SEC = z;
    }

    void showTime() {
        cout << endl << HR << ":" << MIN << ":" << SEC;
    }

    void normalize() {
        MIN = MIN - SEC / 60;
        SEC = SEC % 60;
        HR = HR - MIN / 60;
        MIN = MIN % 60;
    }

    // Overload the -- operator to subtract time
    Time operator--() {
        Time temp;
        temp.HR = HR;
        temp.MIN = MIN;
        temp.SEC = SEC;
        
        // Decrement the time by 1 second
        SEC--;

        // Normalize if SEC becomes negative
        if (SEC < 0) {
            SEC = 59;
            MIN--;
        }

        // Normalize further if MIN becomes negative
        if (MIN < 0) {
            MIN = 59;
            HR--;
        }

        // Normalize HR if it becomes negative
        if (HR < 0) {
            HR = 0; // To prevent negative HR
            MIN = 0;
            SEC = 0;
        }

        return temp;
    }
};

int main() {
    int a, b, c, d, e, f;

    cout << "Enter (a): ";
    cin >> a;
    cout << "Enter (b): ";
    cin >> b;
    cout << "Enter (c): ";
    cin >> c;
    cout << "Enter (d): ";
    cin >> d;
    cout << "Enter (e): ";
    cin >> e;
    cout << "Enter (f): ";
    cin >> f;

    Time t1, t2, t3, t4;
    t1.setTime(a, b, c);
    t2.setTime(d, e, f);

    // Operator overloading
    t3 = --t1;// Decrement t1 by 1 second
     t4 = --t2;
    // Printing results
    t1.showTime();
    t2.showTime();
  

    return 0;
}
