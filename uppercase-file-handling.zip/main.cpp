#include <iostream>
#include <fstream>
#include <cctype> // For toupper function

using namespace std;

// Define the copyupper function outside of main
void copyupper();

int main()
{
    ofstream out;
    out.open("FIRST.TXT");
    out << "hello world\n";
    out.close();
    copyupper();
    return 0; // Added return statement
}

// Define the copyupper function outside of main
void copyupper()
{
    ofstream out1;
    out1.open("SECOND.TXT");
    ifstream in;
    in.open("FIRST.TXT");
    char ch;

    while (!in.eof())
    {
        ch = in.get(); // Read a character from the input file
        if (!in.eof())
        {
            ch = toupper(ch); // Convert the character to uppercase
            cout << ch;
            out1 << ch;
        }
    }
    in.close();
    out1.close(); // Close the output file
}
