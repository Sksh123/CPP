#include <iostream>

class ComplexNumber {
private:
    double real;
    double imaginary;

public:
    ComplexNumber(double r, double i) : real(r), imaginary(i) {}

    void display() {
        if (imaginary >= 0) {
            std::cout << real << " + " << imaginary << "i" << std::endl;
        } else {
            std::cout << real << " - " << -imaginary << "i" << std::endl;
        }
    }
};

int main() {
    ComplexNumber complex(3.0, -2.5);
    complex.display();

    return 0;
}
