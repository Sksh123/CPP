#include <iostream>

class Complex {
private:
    double real;
    double imaginary;

public:
    // Default constructor
    Complex() : real(0.0), imaginary(1.0) {}

    // One-argument constructor
    Complex(double b) : real(0.0), imaginary(b) {}

    // Two-argument constructor
    Complex(double a, double b) : real(a), imaginary(b) {}

    // Display the complex number
    void display() const {
        if (imaginary >= 0) {
            std::cout << real << " + " << imaginary << "i" << std::endl;
        } else {
            std::cout << real << " - " << -imaginary << "i" << std::endl;
        }
    }
};

int main() {
    Complex defaultComplex;
    Complex oneArgComplex(5.0);
    Complex twoArgComplex(3.0, -2.5);

    std::cout << "Default Complex: ";
    defaultComplex.display();

    std::cout << "One-Argument Complex: ";
    oneArgComplex.display();

    std::cout << "Two-Argument Complex: ";
    twoArgComplex.display();

    return 0;
}
