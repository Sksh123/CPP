#include <iostream>
#include <string>

// Base class Furniture
class Furniture {
protected:
    std::string material;
    double price;

public:
    Furniture(const std::string& mat, double pr) : material(mat), price(pr) {}

    void display() {
        std::cout << "Material: " << material << std::endl;
        std::cout << "Price: $" << price << std::endl;
    }
};

// Derived class Table inheriting from Furniture
class Table : public Furniture {
private:
    double height;
    double surfaceArea;

public:
    Table(const std::string& mat, double pr, double ht, double area)
        : Furniture(mat, pr), height(ht), surfaceArea(area) {}

    void display() {
        std::cout << "Table Details" << std::endl;
        Furniture::display();
        std::cout << "Height: " << height << " inches" << std::endl;
        std::cout << "Surface Area: " << surfaceArea << " square inches" << std::endl;
    }
};

// Derived class Chair inheriting from Furniture
class Chair : public Furniture {
private:
    std::string type;
    int manufacturingYear;

public:
    Chair(const std::string& mat, double pr, const std::string& chairType, int year)
        : Furniture(mat, pr), type(chairType), manufacturingYear(year) {}

    void display() {
        std::cout << "Chair Details" << std::endl;
        Furniture::display();
        std::cout << "Chair Type: " << type << std::endl;
        std::cout << "Manufacturing Year: " << manufacturingYear << std::endl;
    }
};

int main() {
    Table diningTable("Wood", 250.0, 30.0, 1500.0);
    Chair officeChair("Plastic", 80.0, "Plastic", 2022);

    diningTable.display();
    std::cout << std::endl;
    officeChair.display();

    return 0;
}
