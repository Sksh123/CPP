#include <iostream>

class Distance {
private:
    int feet;
    int inches;

public:
    Distance(int ft, int in) : feet(ft), inches(in) {}

    // Overload unary - operator (S1 batch)
    Distance operator-() {
        if (inches > 0) {
            inches--;
        } else {
            if (feet > 0) {
                feet--;
                inches = 11;
            }
        }
        return *this;
    }

    // Overload unary + operator (S2 batch)
    Distance operator+() {
        if (inches < 11) {
            inches++;
        } else {
            feet++;
            inches = 0;
        }
        return *this;
    }

    // Overload binary + operator (S3 batch)
    Distance operator+(const Distance& other) {
        int totalFeet = feet + other.feet;
        int totalInches = inches + other.inches;
        if (totalInches >= 12) {
            totalFeet++;
            totalInches -= 12;
        }
        return Distance(totalFeet, totalInches);
    }

    // Overload unary > operator (S4 batch)
    bool operator>(const Distance& other) {
        if (feet > other.feet) {
            return true;
        } else if (feet == other.feet && inches > other.inches) {
            return true;
        }
        return false;
    }

    void display() {
        std::cout << feet << " feet " << inches << " inches" << std::endl;
    }
};

int main() {
    Distance d1(5, 6);
    Distance d2(3, 8);

    std::cout << "Original d1: ";
    d1.display();

    std::cout << "Unary - on d1: ";
    (-d1).display();

    std::cout << "Unary + on d1: ";
    (+d1).display();

    std::cout << "Original d2: ";
    d2.display();

    std::cout << "Unary - on d2: ";
    (-d2).display();

    std::cout << "Unary + on d2: ";
    (+d2).display();

    std::cout << "d1 + d2: ";
    (d1 + d2).display();

    if (d1 > d2) {
        std::cout << "d1 is greater than d2." << std::endl;
    } else {
        std::cout << "d1 is not greater than d2." << std::endl;
    }

    return 0;
}
