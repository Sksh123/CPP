#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
using namespace std;

// Function to create "FIRST.TXT" and write some text to it
void createFirstFile() {
    ofstream firstFile("FIRST.TXT");

    if (!firstFile.is_open()) {
        cerr << "Error: Unable to create 'FIRST.TXT'." << endl;
        return;
    }

    // Write some text to "FIRST.TXT"
    firstFile << "apple banana cat dog elephant frog" << endl;

    firstFile.close();
}

void vowelwords() {
    ifstream ifs("FIRST.TXT");
    ofstream ofs("SECOND.TXT");
    string word;

    while (ifs >> word) {
        int ch = tolower(word[0]);
        if (ch == 'a' || ch == 'e' || ch == 'i' ||
            ch == 'o' || ch == 'u') {
            ofs << word << ' ';
        }
    }
}

int main() {
    // Call createFirstFile to create "FIRST.TXT"
    createFirstFile();

    // Call vowelwords to process "FIRST.TXT" and create "SECOND.TXT"
    vowelwords();

    return 0;
}
