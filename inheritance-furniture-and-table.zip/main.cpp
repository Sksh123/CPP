#include <iostream>
#include <string>

// Base class Furniture
class Furniture {
protected:
    std::string material;
    double price;

public:
    // Parameterized constructor for Furniture
    Furniture(const std::string& mat, double pr) : material(mat), price(pr) {}

    // Display information about the Furniture
    void display() {
        std::cout << "Material: " << material << std::endl;
        std::cout << "Price: $" << price << std::endl;
    }
};

// Derived class Table inheriting from Furniture
class Table : public Furniture {
private:
    double height;
    double surfaceArea;

public:
    // Parameterized constructor for Table
    Table(const std::string& mat, double pr, double ht, double area)
        : Furniture(mat, pr), height(ht), surfaceArea(area) {}

    // Display information about the Table
    void display() {
        std::cout << "Table Details" << std::endl;
        Furniture::display(); // Call the base class display function
        std::cout << "Height: " << height << " inches" << std::endl;
        std::cout << "Surface Area: " << surfaceArea << " square inches" << std::endl;
    }
};

int main() {
    // Create a Table object
    Table diningTable("Wood", 250.0, 30.0, 1500.0);

    // Display information about the Table
    diningTable.display();

    return 0;
}
